var express = require("express");
var router = express.Router();
var expressValidator = require("express-validator");
router.use(expressValidator());
var User = require("../data/register");


//Get Home Page
router.get("/",(req,res) => {
    res.render("home");
});

//Register User
router.post("/home",(req,res) => {
    var username = req.body.unm;
    var password = req.body.pwd;
    var confirmPassword = req.body.conpwd;
    var securityQuestion = req.body.secQ;
    var secA = req.body.secA;

    //Validations
    req.checkBody("unm","username is required").notEmpty();
    req.checkBody("pwd","Please enter password").notEmpty();
    req.checkBody("conpwd","Passwords do not match").equals(password);
    req.checkBody("secA","Please enter security answer").notEmpty();

    var errors = req.validationErrors();
    if(errors)
    {
        res.render("register",{
            errors : errors
        })
    }
    else
    {
        var newUser = new User({
            username : username,
            password : password,
            security_question : securityQuestion,
            security_answer : secA
        })

        User.createUser(newUser,function(err,user){
            if(err) throw err;
            console.log(user);
        })

        req.flash("success_msg","You are registered and can now login");
        res.redirect("/home");
    }

    
});
module.exports = router;