var homeRoutes = require("./home");
var registerRoutes = require("./register");
var dashboardRoutes = require("./dashboard");

var constructorMethod = (app) => {
    app.use("/",homeRoutes);
    app.use("/home",homeRoutes);
    app.use("/register",registerRoutes);
    app.use("/dashboard",dashboardRoutes);
}

module.exports = constructorMethod;