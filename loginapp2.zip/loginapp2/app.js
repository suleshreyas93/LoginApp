var express = require("express");
var exhbs = require("express-handlebars");
var session = require("express-session");
var expressValidator = require("express-validator");
var cookieParser = require("cookie-parser");
var bodyParser = require("body-parser");
var flash = require("connect-flash");
var passport = require("passport");
var LocalStrategy = require("passport-local").Strategy;
var path = require("path");
var mongo = require("mongodb");
var mongoose = require("mongoose");
mongoose.connect("mongodb://localhost/loginapp");
var db = mongoose.connection;

//Init App
var app = express();

//Body Parser Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : false}));





//View Engine
app.set("views",path.join(__dirname,"views"));
app.engine("handlebars",exhbs({defaultLayout : "main"}));
app.set("view engine","handlebars");

//Set Static Folders
const static = express.static(__dirname + "/public");
app.use("/public",static);

//Express session
app.use(session({
    secret : "secret",
    saveUninitialized : true,
    resave : true
}));

//Connect flash
app.use(flash());

//Init passport
app.use(passport.initialize());
app.use(passport.session());


//Express validator
app.use(expressValidator({
  errorFormatter: function(param, msg, value) {
      var namespace = param.split('.')
      , root    = namespace.shift()
      , formParam = root;

    while(namespace.length) {
      formParam += '[' + namespace.shift() + ']';
    }
    return {
      param : formParam,
      msg   : msg,
      value : value
    };
  }
}));



//Global Variables
app.use(function(req,res,next){
    res.locals.success_msg = req.flash("success_msg");
    res.locals.error_msg = req.flash("error_msg");
    res.locals.error = req.flash("error");
    next();
});

//Configure Routes
var configRoutes = require("./routes");
configRoutes(app);

app.listen(3000, () => {
    console.log("We have got a server");
    console.log("Your routes will be running on http://localhost:3000");
}); 