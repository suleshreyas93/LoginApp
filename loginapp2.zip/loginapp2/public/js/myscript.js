// $("document").ready(function(){
//     $("#error").hide();
//     $("#form").submit(function(e){
//         e.preventDefault();
//         var unm = $("input#unm").val();
//         if(unm == "")
//         {
//             $("#error").show();
//             $("#error").html("Please enter username");
//         }
//         else
//         {

//         }
//     })
// })
console.log('hi');