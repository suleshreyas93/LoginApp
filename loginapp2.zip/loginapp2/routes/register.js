var express = require("express");
var router = express.Router();

//Get Registration Page
router.get("/",(req,res) => {
    res.render("register");
});

module.exports = router;